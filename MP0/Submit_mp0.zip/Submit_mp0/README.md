Xinyu Lian 3180111341

#### how to build and run your code
You can directly run ./test.sh to test my code and the ouput is in history.log

#### functionality
You can check the output in history.log

#### collecting delay and bandwidth measurements
I use a script to run and collect the information : `analysis.py`

#### producing readable plots
Please refer to figure1 and figure2
The figure is not so beautiful. But mostly, the bandwith of A increases as R increase. And the delay do not have a clear trend. 